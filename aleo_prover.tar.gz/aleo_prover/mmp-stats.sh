#!/usr/bin/env bash
# This file will contain functions related to gathering stats and displaying it for agent
# Agent will have to call mmp-stats.sh which will contain triggers for configuration files and etc.
# Do not add anything static in this file
GPU_COUNT=$1
LOG_FILE=$2
COUNT_FILE="/tmp/solutions.cache"
cd `dirname $0`
. mmp-external.conf

get_bus_ids() {
    local vendor_id="$1"
    local bus_ids=$(/bin/lspci -n | awk '$2 ~ /^0300|0302:/ && $3 ~ /^'"${vendor_id}"':/ {print $1}')
    local decimal_bus_ids=()

    if [ -z "$bus_ids" ]; then
        exit 1
    fi

    while read -r bus_id; do
        local decimal_bus_id=$((16#${bus_id%%:*}))
        decimal_bus_ids+=("$decimal_bus_id")
    done <<< "$bus_ids"

    echo "${decimal_bus_ids[*]}"
}

get_cards_hashes() {
    hash=''
    for (( i=0; i < ${GPU_COUNT}; i++ )); do
        hash[$i]=''
        local HS=$(grep "gpu\[$i\]" $LOG_FILE | sed -n 's/.*1m - \([^ ]*\).*/\1/p'|tail -n1)
        if [[ -z "$HS" || "$HS" == "N/A" ]]; then
            local HS="0"
        fi
        if [[ ${HS} > 0 ]]; then
            hash[$i]=`echo $HS`
        fi
    done
}

get_cards_solutions() {
    ac=0
    TMP_CNT_FILE=$(mktemp)
    # A simple workaround to count all found solutions by making each target unique.
    grep -oP 'target \K[0-9]+' "$LOG_FILE" | while read -r target; do
        if [[ -n "$target" ]]; then
            echo "$target" >> "$TMP_CNT_FILE"
        fi
    done
    sort "$TMP_CNT_FILE" | uniq -c | awk '{print $2, $1}' > "$COUNT_FILE"
    while read -r target count; do
        ac=$((ac + count))
    done < "$COUNT_FILE"
    rm "$TMP_CNT_FILE"
    echo $ac
}

get_miner_stats() {
    stats=
    local hash=
    get_cards_hashes                        # hashes array
    bus_ids=$(get_bus_ids "10de")
    local busid=("${bus_ids[@]}")
    local units='hs'                    # hashes units
    local ac=$(get_cards_solutions)
    stats=$(jq -nc \
            --argjson hash "$(echo ${hash[@]} | tr " " "\n" | jq -cs '.')" \
            --argjson busid "$(echo ${busid[@]} | tr " " "\n" | jq -cs '.')" \
            --arg units "$units" \
            --arg ac "$ac" --arg inv "0" --arg rj "0" \
            --arg miner_version "$EXTERNAL_VERSION" \
            --arg miner_name "$EXTERNAL_NAME" \
        '{$busid, $hash, $units, air: [$ac, $inv, $rj], miner_name: $miner_name, miner_version: $miner_version}')
    # total hashrate in hs
    echo $stats
}
get_miner_stats $GPU_COUNT $LOG_FILE

